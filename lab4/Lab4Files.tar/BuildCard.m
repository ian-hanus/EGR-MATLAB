function CardString = BuildCard(CardNum)
CardVal  = 1; % fix this!
CardSuit = 1; % fix this!
%% Get card value - this works already!
Vals  = ['A23456789XJQK'];
CardString(1) = Vals(CardVal);

%% Get card suit - you have to do all this!

end