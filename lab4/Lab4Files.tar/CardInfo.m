function [Val, Suit] = CardInfo(C)
%% Get value from the first character
if C(1)=='A'
    Val=1;
elseif C(1)=='X'
    Val=10;
% add code for jack, queen, and king
else % the card must be a 2 through a 9 if we're here
    Val= str2num(C(1));
end

%% If the above tree doesn't assign a value, make it 0 by default
if isempty(Val)
    Val=0;
end

%% Get suit fromt the second character
switch C(2)
% this is all you!  Assign Suit to the right value!
    otherwise 
        Suit=0;
end
