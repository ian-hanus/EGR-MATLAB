%% Placeholder to at least produce something!
function out=CheckTOK(in, p)
out = 0;