%% Initialize the workspace
clear; format short e
%% Define anonymous equation - fix this
yfun = @(alpha, beta, xi) alpha.*beta.*xi
%% Make plots
x = 0:pi/40:pi/2;
figure(1); clf
plot(x, yfun(2, 5, x), 'ms--', 'LineWidth', 2,   'MarkerSize',  16, 'MarkerFaceColor', 'y')
hold on
%% other plots here - you have to do this
hold off
grid on
legend('(2,5)', '(4,5)', '(2,10)', 'location', 'best')
print -depsc Chapra02p10Plot1