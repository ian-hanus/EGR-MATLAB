function TOKTester(p)
% TOKTester(p)
% If no p or p=0, only print grade
% If p=1, show only incorrect entries
% If p=2, show only three of a kind
% If p=3, show all hands
%
% Prints hand, what your code thinks about it, and if that is correct
% Example printout:
% Hand: QD QC KC yes: Incorrect!
% If your code thinks QD QC KC is a three of a kind, that is incorrect
%
% Your grade is saved to TTDiary.txt
