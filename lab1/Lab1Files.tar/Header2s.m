 % [Function or Script Name]
 % [Your Name]
 % [Date Modified]
 % Based on: [Original Script or Function]
 % Written by: [Original Author]

 % I have adhered to all the tenets of the 
 % Duke Community Standard in creating this code.
 % Signed: [Your NetID]
