clear; format short e

n = input('Number [0, 10]: ');
while ~(0<=n & n<=10)
    n = input('Number [0, 10]: ')
end