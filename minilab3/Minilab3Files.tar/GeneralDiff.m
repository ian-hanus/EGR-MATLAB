function dydt = GeneralDiff(t, y, C)
% Template for calculating first derivatives of state variables
% t is time
% y is the state vector
% C contains any required constants
% dydt must be a column vector
dydt =
